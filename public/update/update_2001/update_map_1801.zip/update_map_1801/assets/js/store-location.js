//location
var indonesia = [
  ["PT Tirtakencana Tatawarna","Surabaya Jawa Timur","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -7.262565,112.739566],
  ["PT Tirtakencana Tatawarna","Madura Jawa Timur","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -7.008236, 113.858342],
  ["PT Tirtakencana Tatawarna","Malang Jawa Timur","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -7.967594, 112.635387],
  ["PT Tirtakencana Tatawarna","Semarang Jawa Tengah","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -7.967594, 112.635387],
  ["PT Tirtakencana Tatawarna","Yogyakarta Jawa Tengah","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -7.795682, 110.369437],
  ["PT Tirtakencana Tatawarna","Bandung Jawa Barat","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -6.916229, 107.618266],
  ["PT Tirtakencana Tatawarna","Jakarta DKI Jakarta","Jalan mawar 12/13","+62 31 567 8990","adminsbytimur@tirtakencanatatawarna.com", -6.208922, 106.845652]
];

// var madura = [

// ];

// var malang = [

// ];

// var semarang = [

// ];

// var yogyakarta = [

// ];

// var bandung = [

// ];

// var jakarta = [

// ];



